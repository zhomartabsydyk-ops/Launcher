package com.rbx.hotkey

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 48, 48, 48) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }.also { root.addView(it) }
        root.addView(TextView(this).apply {
            textSize = 16f
            text = "1) Включи службу «RBX Launcher» в Специальных возможностях.\n" +
                "2) Дай доступ к изменению системных настроек и к «Не беспокоить».\n" +
                "3) Запусти Roblox и нажми Right Shift — откроется панель."
        })
        btn("Специальные возможности") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("Доступ к системным настройкам") {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).setData(android.net.Uri.parse("package:$packageName")))
        }
        btn("Доступ к «Не беспокоить»") { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
        btn("Запустить Roblox") {
            val i = packageManager.getLaunchIntentForPackage("com.roblox.client")
            if (i != null) startActivity(i) else Toast.makeText(this, "Roblox не установлен", Toast.LENGTH_SHORT).show()
        }
        setContentView(root)
    }
}
