package com.rbx.hotkey

import android.accessibilityservice.AccessibilityService
import android.app.ActivityManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.BatteryManager
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class HotkeyService : AccessibilityService() {
    private var panel: View? = null
    private var stats: TextView? = null

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // Right Shift только переключает панель; клавиша не перехватывается, игра её тоже получает.
    override fun onKeyEvent(e: KeyEvent): Boolean {
        if (e.keyCode == KeyEvent.KEYCODE_SHIFT_RIGHT && e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) toggle()
        return false
    }

    private fun toggle() { if (panel == null) show() else hide() }

    private fun hide() {
        panel?.let { runCatching { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } }
        panel = null; stats = null
    }

    private fun show() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(32, 32, 32, 32); setBackgroundColor(Color.argb(230, 20, 20, 24))
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }.also { box.addView(it) }
        box.addView(TextView(this).apply { text = "RBX Launcher"; setTextColor(Color.WHITE); textSize = 18f })
        stats = TextView(this).apply { setTextColor(Color.LTGRAY) }.also { box.addView(it) }
        btn("Режим производительности") { performance(true) }
        btn("Обычный режим") { performance(false) }
        btn("Обновить данные") { refreshStats() }
        btn("Закрыть (Right Shift)") { hide() }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 24; y = 24 }
        (getSystemService(WINDOW_SERVICE) as WindowManager).addView(box, lp)
        panel = box
        refreshStats()
    }

    private fun refreshStats() {
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val bat = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = (bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        val lvl = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        stats?.text = "RAM свободно: ${mi.availMem / 1048576} МБ\nБатарея: $lvl%, ${temp}°C"
    }

    private fun performance(on: Boolean) {
        var msg = ""
        // Частота обновления (ключи зависят от производителя, нужен доступ к системным настройкам).
        if (Settings.System.canWrite(this)) {
            runCatching {
                val hz = if (on) 120f else 60f
                Settings.System.putFloat(contentResolver, "min_refresh_rate", if (on) hz else 0f)
                Settings.System.putFloat(contentResolver, "peak_refresh_rate", hz)
            }
        } else msg += "Нет доступа к системным настройкам. "
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.isNotificationPolicyAccessGranted) {
            nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_NONE else NotificationManager.INTERRUPTION_FILTER_ALL)
        } else msg += "Нет доступа к «Не беспокоить»."
        Toast.makeText(this, if (msg.isEmpty()) (if (on) "Режим производительности включён" else "Обычный режим") else msg, Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() { hide(); super.onDestroy() }
}
